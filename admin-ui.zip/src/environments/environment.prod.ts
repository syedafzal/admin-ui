export const environment = {
  production: true,
  URL: 'https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json'
};
