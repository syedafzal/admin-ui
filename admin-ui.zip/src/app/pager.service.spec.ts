import { TestBed, async } from "@angular/core/testing";
import { SearchPipe } from "./search.pipe";
import { PagerService } from "./pager.service";
import { user } from "./user.interface";
import { of } from "rxjs/internal/observable/of";

describe("PagerService", () => {
  let service: PagerService;
  let pipe: SearchPipe;
  let mockData: user[] = [
    {
      id: 1,
      name: "Aaron Miles",
      email: "aaron@mailinator.com",
      role: "member",
    },
    {
      id: 2,
      name: "Aishwarya Naik",
      email: "aishwarya@mailinator.com",
      role: "admin",
    },
  ];
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchPipe, PagerService],
    });
  });

  beforeEach(() => {
    service = TestBed.get(PagerService);
    pipe = TestBed.get(SearchPipe);
  });

  it("should be created", () => {
    expect(service).toBeTruthy();
  });

  it("should call searchpipe transform from pager", () => {
    const spied = spyOn(pipe, "transform").and.returnValue(mockData);

    service.paginate(1, "", mockData);
    console.log(service.displayData);
    expect(service.displayData).toEqual(mockData);
    expect(spied).toHaveBeenCalled();
  });

  it("should not call searchpipe for null data", () => {
    spyOn(pipe, "transform");
    service.paginate(1, "", null);
    expect(pipe.transform).not.toHaveBeenCalled();
  });
});
