import { TestBed, async, fakeAsync } from "@angular/core/testing";
import { AppComponent } from "./app.component";
import {
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatSelectModule,
  MatTableModule,
} from "@angular/material";
import { PagerService } from "./pager.service";
import { DataService } from "./data.service";
import { PaginationComponent } from "./pagination/pagination.component";
import { UserTableComponent } from "./user-table/user-table.component";
import { FormsModule } from "@angular/forms";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { SearchPipe } from "./search.pipe";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { By } from "@angular/platform-browser";
import { user } from "./user.interface";
import { of } from "rxjs/internal/observable/of";

describe("AppComponent", () => {
  const mockData: user[] = [
    {
      id: 1,
      name: "Aaron Miles",
      email: "aaron@mailinator.com",
      role: "member",
    },
    {
      id: 2,
      name: "Aishwarya Naik",
      email: "aishwarya@mailinator.com",
      role: "admin",
    },
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AppComponent, PaginationComponent, UserTableComponent],
      imports: [
        BrowserAnimationsModule,
        MatTableModule,
        MatInputModule,
        MatCardModule,
        MatButtonToggleModule,
        MatButtonModule,
        FormsModule,
        MatFormFieldModule,
        MatCheckboxModule,
        MatSelectModule,
        MatIconModule,
        HttpClientTestingModule,
      ],
      providers: [DataService, PagerService, SearchPipe],
    }).compileComponents();
  }));

  it("should create the app", () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'admin-ui'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual("admin-ui");
  });

  it("should render child component", () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const pagination = fixture.debugElement.queryAll(
      By.directive(PaginationComponent)
    );
    const usertable = fixture.debugElement.queryAll(
      By.directive(UserTableComponent)
    );
    expect(usertable).toBeTruthy();
  });

  it("should set datasource by service", fakeAsync(() => {
    const dataService = TestBed.get(DataService);
    const pagerService = TestBed.get(PagerService);
    spyOn(dataService, "getData").and.returnValue(of(mockData));
    spyOn(pagerService, "getDisplayData").and.returnValue(of(mockData));
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    fixture.detectChanges();
    expect(app.dataSource).toEqual(mockData);
  }));
});
