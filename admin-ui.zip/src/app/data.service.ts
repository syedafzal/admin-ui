import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { user } from "./user.interface";
import { BehaviorSubject, Observable, Subject } from "rxjs";
import { environment } from "../environments/environment";

@Injectable({
  providedIn: "root",
})
export class DataService {
  apiUrl = environment.URL;
  userData: user[];
  userDataSubject = new Subject<user[]>();
  userDataTrans = this.userDataSubject.asObservable();

  constructor(private http: HttpClient) {}
  /**
   * @returns user data from API call
   */
  getData() {
    return this.http.get<user[]>(this.apiUrl);
  }
  /**
   * sets the input data and updates subscribers
   * @param data users data array
   */
  setUserData(data: user[]) {
    this.userData = data;
    this.userDataSubject.next(data);
  }
  /**
   * @returns userdata observable for subscribing
   */
  getUserData(): Observable<user[]> {
    return this.userDataTrans;
  }
  /**
   * deletes user object and updates subscribers
   * @param index of user object
   */
  deleteUser(index: number) {
    this.userData.splice(index, 1);
    this.userDataSubject.next(this.userData);
  }
  /**
   * updates user object and updates subscribers
   * @param index of user object
   * @param updatedUser
   */
  updateUser(index: number, updatedUser: user) {
    if (null == updatedUser) return;
    this.userData[index] = updatedUser;
    this.userDataSubject.next(this.userData);
  }
  /**
   *
   * @param users array
   * @param left leftmost index
   * @param right rightmost index
   * @param subject user id to search
   * @returns index of user object or -1 otherwise
   */
  binarySearch(
    users: user[],
    left: number,
    right: number,
    subject: number
  ): number {
    subject = subject * 1;
    if (right >= left) {
      let mid = Math.floor(left + (right - left) / 2);

      if (users[mid].id * 1 == subject) return mid;

      if (users[mid].id * 1 > subject)
        return this.binarySearch(users, left, mid - 1, subject);

      return this.binarySearch(users, mid + 1, right, subject);
    }
    // not found
    return -1;
  }
}
