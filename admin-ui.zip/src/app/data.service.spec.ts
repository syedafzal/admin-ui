import { TestBed, async } from "@angular/core/testing";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { DataService } from "./data.service";
import { environment } from "src/environments/environment";
import { user } from "./user.interface";
describe("DataService", () => {
  let httpTestingController: HttpTestingController;
  let service: DataService;
  const mockData: user[] = [
    {
      id: 1,
      name: "Aaron Miles",
      email: "aaron@mailinator.com",
      role: "member",
    },
  ];
  const mockUser = {
    id: 2,
    name: "Aishwarya Naik",
    email: "aishwarya@mailinator.com",
    role: "admin",
  };
  const mockDataBinary = [
    { id: 1 },
    { id: 2 },
    { id: 4 },
    { id: 5 },
    { id: 6 },
  ];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DataService],
    });
    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(DataService);
  }));

  afterEach(() => {
    httpTestingController.verify();
  });

  it("should be created", () => {
    const service: DataService = TestBed.get(DataService);
    expect(service).toBeTruthy();
  });

  it("should return data for #getData", (done: DoneFn) => {
    service.getData().subscribe((data) => {
      expect(data).not.toBeNull();
      done();
    });
    const testRequest = httpTestingController.expectOne(environment.URL);
    testRequest.flush({});
  });

  it("should update user for valid user", () => {
    service.setUserData(mockData);
    service.updateUser(0, mockUser);
    expect(service.userData[0]).toEqual(mockUser);
  });

  it("should not update user for invalid user", () => {
    service.setUserData(mockData);
    service.updateUser(0, null);
    expect(service.userData[0]).not.toBeNull();
  });

  it("should find user id in begining", () => {
    const index = service.binarySearch(mockDataBinary as user[], 0, 4, 1);
    expect(index).toBe(0);
  });

  it("should find user id in end", () => {
    const index = service.binarySearch(mockDataBinary as user[], 0, 4, 6);
    expect(index).toBe(4);
  });

  it("should find user id in mid", () => {
    const index = service.binarySearch(mockDataBinary as user[], 0, 4, 4);
    expect(index).toBe(2);
  });

  it("should not find invalid user id", () => {
    const index = service.binarySearch(mockDataBinary as user[], 0, 4, 3);
    expect(index).toBe(-1);
  });
});
