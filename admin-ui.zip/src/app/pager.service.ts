import { Injectable } from "@angular/core";
import { AppComponent } from "./app.component";
import { user } from "./user.interface";
import { Observable, Subject } from "rxjs";
import { SearchPipe } from "./search.pipe";
import { UserTableService } from "./user-table.service";

@Injectable({
  providedIn: "root",
})
export class PagerService {
  constructor(private pipe: SearchPipe) {}

  displayData: user[];
  displayDataSubject = new Subject<user[]>();
  displayDataTransfer = this.displayDataSubject.asObservable();

  //pagination
  totalItem = 0;
  ITEMS_PER_PAGE = 10;
  WINDOW_SIZE = 5;
  pageNumberingArray: number[];
  currentPage = 1;
  startIndex = 0;
  endIndex = this.ITEMS_PER_PAGE - 1;
  searchText = "";
  pageNumberSubject = new Subject<number[]>();
  pageNumberTrans = this.pageNumberSubject.asObservable();

  allSelected: boolean = false;

  getPageNumbers(): Observable<number[]> {
    return this.pageNumberTrans;
  }
  getDisplayData(): Observable<user[]> {
    return this.displayDataTransfer;
  }
  /**
   * sets indexes for current page number & generates page numbering
   * @param currentPage
   * @param searchText
   * @param masterData
   * @returns void and updates display data and page numbering to subscribers
   */
  paginate(currentPage = 1, searchText: string, masterData: user[]) {
    if (!masterData) return;
    this.displayData = this.pipe.transform(masterData, searchText);
    this.totalItem = this.displayData.length;

    let totalPage = Math.ceil(this.totalItem / this.ITEMS_PER_PAGE);

    currentPage = currentPage < 1 ? 1 : currentPage;
    currentPage = currentPage > totalPage ? totalPage : currentPage;
    this.currentPage = currentPage;

    let pageNumberingArray = [];
    for (let i = 0; i < totalPage; i++) {
      pageNumberingArray.push(i);
    }
    this.pageNumberingArray = pageNumberingArray;
    this.pageNumberSubject.next(this.pageNumberingArray);
    this.startIndex = (currentPage - 1) * this.ITEMS_PER_PAGE;
    this.endIndex =
      currentPage * this.ITEMS_PER_PAGE - 1 < this.totalItem
        ? currentPage * this.ITEMS_PER_PAGE - 1
        : this.totalItem - 1;
    this.displayData = this.displayData.slice(
      this.startIndex,
      this.endIndex + 1
    );
    this.displayDataSubject.next(this.displayData);
  }
}
