import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class UserTableService {
  searchTextSubject = new BehaviorSubject<string>("");
  searchTextTransfer = this.searchTextSubject.asObservable();

  constructor() {}

  getSearchText() {
    return this.searchTextTransfer;
  }
  updateSearchText(text) {
    this.searchTextSubject.next(text);
  }
}
