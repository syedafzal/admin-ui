import { Pipe, PipeTransform } from "@angular/core";
import { user } from "./user.interface";

@Pipe({
  name: "search",
})
export class SearchPipe implements PipeTransform {
  transform(value: user[], ...args: any[]): any {
    if (!args[0]) return value;
    let searchText = String(args[0]).toLowerCase();

    let result = value.filter((user) => {
      //loop through each object
      let found = false;

      //check if object value contains value looking for
      if (user.name.toLowerCase().includes(searchText)) {
        //add this object to the filtered array
        return user;
      }
      if (user.email.toLowerCase().includes(searchText)) {
        //add this object to the filtered array
        return user;
      }
      if (user.role.toLowerCase().includes(searchText)) {
        return user;
      }

      return null;
    });
    return result;
  }
}
