import { Component, OnDestroy, OnInit } from "@angular/core";
import { PagerService } from "../pager.service";
import { DataService } from "../data.service";
import { user } from "../user.interface";
import { UserTableService } from "../user-table.service";
import { Subscription } from "rxjs";

@Component({
  selector: "pagination",
  templateUrl: "./pagination.component.html",
  styleUrls: ["./pagination.component.scss"],
})
export class PaginationComponent implements OnInit, OnDestroy {
  pageNumbersArray: number[];
  currentPage = 1;
  userData: user[];
  searchText = "";

  pagerServiceSubscription: Subscription;
  dataServiceSubscription: Subscription;
  tableServiceSubscription: Subscription;

  constructor(
    private pagerService: PagerService,
    private dataService: DataService,
    private tableService: UserTableService
  ) {}

  ngOnInit() {
    this.pageNumbersArray = [0];
    this.dataServiceSubscription = this.dataService
      .getUserData()
      .subscribe((data) => {
        this.userData = data;
        this.paginate(this.currentPage);
      });

    this.pagerServiceSubscription = this.pagerService
      .getPageNumbers()
      .subscribe((numbers) => {
        this.pageNumbersArray = numbers;
      });
    this.tableServiceSubscription = this.tableService
      .getSearchText()
      .subscribe((text) => {
        this.searchText = text;
        this.paginate(this.currentPage);
      });
  }
  /**
   * calls paginate of service to get updated observables on page change
   * @param currentPage
   */
  paginate(currentPage = 1) {
    if (currentPage < this.pageNumbersArray[0] + 1) return;
    if (
      currentPage >
      this.pageNumbersArray[this.pageNumbersArray.length - 1] + 1
    )
      return;
    this.pagerService.paginate(currentPage, this.searchText, this.userData);
    this.currentPage = currentPage;
  }

  ngOnDestroy(): void {
    if (this.dataServiceSubscription)
      this.dataServiceSubscription.unsubscribe();
    if (this.pagerServiceSubscription)
      this.pagerServiceSubscription.unsubscribe();
    if (this.tableServiceSubscription)
      this.tableServiceSubscription.unsubscribe();
  }
}
