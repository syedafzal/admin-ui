import {
  async,
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from "@angular/core/testing";

import { PaginationComponent } from "./pagination.component";
import {
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatFormFieldModule,
  MatTableModule,
} from "@angular/material";
import { DataService } from "../data.service";
import { PagerService } from "../pager.service";
import { FormsModule } from "@angular/forms";
import { UserTableService } from "../user-table.service";
import { SearchPipe } from "../search.pipe";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { user } from "../user.interface";
import { of } from "rxjs/internal/observable/of";

describe("PaginationComponent", () => {
  let component: PaginationComponent;
  let fixture: ComponentFixture<PaginationComponent>;
  let pagerService: PagerService;
  let dataService: DataService;
  let tableService: UserTableService;
  const mockData: user[] = [
    {
      id: 1,
      name: "Aaron Miles",
      email: "aaron@mailinator.com",
      role: "member",
    },
    {
      id: 2,
      name: "Aishwarya Naik",
      email: "aishwarya@mailinator.com",
      role: "admin",
    },
  ];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PaginationComponent],
      imports: [
        MatTableModule,
        MatCardModule,
        MatButtonToggleModule,
        MatButtonModule,
        FormsModule,
        MatFormFieldModule,
        MatCheckboxModule,
        HttpClientTestingModule,
      ],
      providers: [DataService, PagerService, UserTableService, SearchPipe],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginationComponent);
    component = fixture.componentInstance;
    pagerService = TestBed.get(PagerService);
    dataService = TestBed.get(DataService);
    tableService = TestBed.get(UserTableService);
    spyOn(tableService, "getSearchText").and.returnValue(of("abc"));
    spyOn(pagerService, "getPageNumbers").and.returnValue(of([0]));
    spyOn(dataService, "getUserData").and.returnValue(of(mockData));
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should unsubscribe on destroy", () => {
    spyOn(component, "ngOnDestroy");
    fixture.destroy();
    expect(component.ngOnDestroy).toHaveBeenCalled();
    expect(component.pagerServiceSubscription.closed).toBeTruthy();
    expect(component.dataServiceSubscription.closed).toBeTruthy();
  });

  it("should unsubscribe alive subscription on destroy", () => {
    spyOn(component, "ngOnDestroy");
    component.dataServiceSubscription.unsubscribe();
    fixture.destroy();
    expect(component.ngOnDestroy).toHaveBeenCalled();
    expect(component.pagerServiceSubscription.closed).toBeTruthy();
  });

  it("should initialize pagination component", () => {
    expect(component.searchText).toEqual("abc");
    expect(component.userData).toEqual(mockData);
    expect(component.pageNumbersArray).toEqual([0]);
  });

  it("should call paginate service", () => {
    spyOn(pagerService, "paginate");
    component.paginate();
    expect(pagerService.paginate).toHaveBeenCalledWith(1, "abc", mockData);
  });

  it("should not call paginate service for current page less than 1", () => {
    spyOn(pagerService, "paginate");
    component.paginate(-1);
    expect(pagerService.paginate).not.toHaveBeenCalledWith(-1, "abc", mockData);
  });

  it("should call not paginate service for current page more than page number", () => {
    spyOn(pagerService, "paginate");
    component.paginate(2);
    expect(pagerService.paginate).not.toHaveBeenCalledWith(2, "abc", mockData);
  });
});
