import {
  Component,
  OnChanges,
  OnInit,
  SimpleChanges,
  ElementRef,
  ViewChild,
  OnDestroy,
} from "@angular/core";
import { MatTable, MatTableModule } from "@angular/material/table";
import { DataService } from "./data.service";
import { user } from "./user.interface";
import { Observable, Subscription } from "rxjs";
import { SearchPipe } from "./search.pipe";
import { MatIconRegistry } from "@angular/material";
import { FormControl, NgModel, Validators } from "@angular/forms";
import { PagerService } from "./pager.service";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent implements OnInit, OnDestroy {
  title = "admin-ui";
  data: user[];
  displayedColumns: string[];
  dataSource: user[];

  dataServiceSubscription: Subscription;
  pagerServiceSubscription: Subscription;
  constructor(
    private dataService: DataService,
    private pagerService: PagerService
  ) {}

  ngOnInit() {
    this.dataService.getData().subscribe((response) => {
      this.data = response;
      this.dataSource = [...response]; // copy of user array
      this.dataService.setUserData(this.data);
      this.displayedColumns = ["select", "name", "email", "role", "action"];
    });
    this.pagerService.getDisplayData().subscribe((data) => {
      this.dataSource = data;
    });
  }
  getDisplayData() {
    return this.pagerService.getDisplayData();
  }
  ngOnDestroy(): void {
    if (this.dataServiceSubscription)
      this.dataServiceSubscription.unsubscribe();
    if (this.pagerServiceSubscription)
      this.pagerServiceSubscription.unsubscribe();
  }
}
