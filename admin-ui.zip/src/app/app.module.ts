import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from "@angular/common/http";
import { MatTableModule } from "@angular/material/table";
import { FormsModule } from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatCardModule } from "@angular/material/card";
import { MatButtonModule } from "@angular/material/button";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { SearchPipe } from "./search.pipe";
import { DataService } from "./data.service";
import { MatGridListModule } from "@angular/material/grid-list";
import { MatIconModule } from "@angular/material/icon";
import { MatRippleModule } from "@angular/material/core";
import { MatDialogModule } from "@angular/material/dialog";
import { MatSelectModule } from "@angular/material/select";
import { PaginationComponent } from "./pagination/pagination.component";
import { UserTableComponent } from "./user-table/user-table.component";

@NgModule({
  declarations: [
    AppComponent,
    SearchPipe,
    PaginationComponent,
    UserTableComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatTableModule,
    MatCheckboxModule,
    FormsModule,
    MatFormFieldModule,
    MatCardModule,
    MatInputModule,
    MatButtonToggleModule,
    MatButtonModule,
    MatGridListModule,
    MatIconModule,
    MatRippleModule,
    MatDialogModule,
    MatSelectModule,
  ],
  providers: [SearchPipe, DataService],
  bootstrap: [AppComponent],
})
export class AppModule {}
