import { Component, Input, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { user } from "../user.interface";
import { DataService } from "../data.service";
import { NgModel } from "@angular/forms";
import { UserTableService } from "../user-table.service";
import { Subscription } from "rxjs";

@Component({
  selector: "user-table",
  templateUrl: "./user-table.component.html",
  styleUrls: ["./user-table.component.scss"],
})
export class UserTableComponent implements OnInit, OnDestroy {
  @Input() dataSource: user[];
  @Input() displayedColumns: string[];
  @ViewChild("emailv", { read: NgModel, static: false }) emailValidator;
  @ViewChild("namev", { read: NgModel, static: false }) nameValidator;

  data: user[];
  PLACEHOLDER_TEXT = "search by name, email or role";
  searchText: string;
  userPlaceHolder: user;
  allSelected: boolean = false;

  dataServiceSubscription: Subscription;

  constructor(
    private dataService: DataService,
    private tableService: UserTableService
  ) {}

  ngOnInit() {
    this.dataServiceSubscription = this.dataService
      .getUserData()
      .subscribe((data) => {
        this.data = data;
      });
    this.allSelected = false;
  }
  /**
   * Updates searchText in service, used in filtering users
   * @param searchTerm entered in search box
   */
  searchChange(searchTerm: string): void {
    this.tableService.updateSearchText(searchTerm);
  }
  /**
   * updates user data in service after its edited
   */
  update() {
    if (
      this.userPlaceHolder &&
      !this.emailValidator.invalid &&
      !this.nameValidator.invalid
    ) {
      let id = this.getUser(this.userPlaceHolder.id);
      this.userPlaceHolder.isEditOn = false;
      this.dataService.updateUser(id, this.userPlaceHolder);
    }
    this.userPlaceHolder = null;
  }
  /**
   * Setup user data for edit.
   * @param user object
   * @returns true when given user is the one set for edit
   */
  edit(user: user) {
    if (this.userPlaceHolder && this.userPlaceHolder.id) {
      return user.id == this.userPlaceHolder.id;
    }
    this.userPlaceHolder = { ...user };
    return true;
  }
  /**
   * Flags user data for select all checkbox
   * @param checked state of the checkbox
   */
  setAllSelected(checked: boolean) {
    this.allSelected = checked;
    this.dataSource.forEach((user) => {
      user.isSelected = checked;
    });
  }
  /**
   * returns true when only some users are selected in the page
   */
  someSelected() {
    let ret = false;
    if (!this.allSelected)
      this.dataSource.forEach((user) => {
        if (user.isSelected) {
          ret = true;
          return;
        }
      });
    return ret;
  }
  /**
   * Updates all selected flag after change in selection of users
   */
  updateSelected() {
    let ret = true;
    this.dataSource.forEach((user) => {
      ret = ret && user.isSelected;
    });
    this.allSelected = ret;
  }
  /**
   * calls delete for selected users
   */
  deleteSelection() {
    this.dataSource.forEach((user) => {
      if (user.isSelected) this.delete(user.id);
    });
  }
  /**
   * Deletes a user based on its id
   * @param id of user
   */
  delete(id: number) {
    let index = this.getUser(id);
    this.dataService.deleteUser(index);
    if (this.userPlaceHolder && id == this.userPlaceHolder.id)
      this.userPlaceHolder = null;
    this.updateSelected();
  }
  /**
   * @param id of user
   * @returns index of user object in data
   */
  getUser(id: number): number {
    //ensuring id is number
    id = 1 * id;
    let ret = this.dataService.binarySearch(
      this.data,
      0,
      this.data.length - 1,
      id
    );
    return ret;
  }

  ngOnDestroy(): void {
    if (this.dataServiceSubscription)
      this.dataServiceSubscription.unsubscribe();
  }
}
