import {
  async,
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from "@angular/core/testing";

import { UserTableComponent } from "./user-table.component";
import { UserTableService } from "../user-table.service";
import { SearchPipe } from "../search.pipe";
import { DataService } from "../data.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { FormsModule } from "@angular/forms";
import {
  MatTableModule,
  MatInputModule,
  MatCardModule,
  MatButtonToggleModule,
  MatButtonModule,
  MatFormFieldModule,
  MatCheckboxModule,
  MatSelectModule,
  MatIconModule,
} from "@angular/material";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { user } from "../user.interface";
import { of } from "rxjs/internal/observable/of";

describe("UserTableComponent", () => {
  let component: UserTableComponent;
  let fixture: ComponentFixture<UserTableComponent>;
  let service: DataService;
  const mockData: user[] = [
    {
      id: 1,
      name: "Aaron Miles",
      email: "aaron@mailinator.com",
      role: "member",
      isEditOn: false,
      isSelected: false,
    },
    {
      id: 2,
      name: "Aishwarya Naik",
      email: "aishwarya@mailinator.com",
      role: "admin",
      isEditOn: false,
      isSelected: false,
    },
  ];
  const displayedColumns = ["select", "name", "email", "role", "action"];
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserTableComponent],
      imports: [
        BrowserAnimationsModule,
        MatTableModule,
        MatInputModule,
        MatCardModule,
        MatButtonToggleModule,
        MatButtonModule,
        FormsModule,
        MatFormFieldModule,
        MatCheckboxModule,
        MatSelectModule,
        MatIconModule,
        HttpClientTestingModule,
      ],
      providers: [DataService, UserTableService, SearchPipe],
    }).compileComponents();
  });

  beforeEach(async () => {
    fixture = TestBed.createComponent(UserTableComponent);
    component = fixture.componentInstance;
    component.data = mockData;
    component.dataSource = mockData;
    component.displayedColumns = displayedColumns;
    service = TestBed.get(DataService);
    spyOn(service, "getUserData").and.returnValue(of(mockData));
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should call edit function on clicking edit icon", fakeAsync(() => {
    spyOn(component, "edit");
    const compiled = fixture.debugElement.nativeElement;
    const icon = compiled.querySelector('[aria-label="edit icon"]');
    icon.click();
    fixture.detectChanges();
    tick();
    expect(component.edit).toHaveBeenCalled();
  }));

  it("should call delete for deleting item", () => {
    const editSpy = spyOn(component, "delete");
    fixture.whenStable().then(() => {});
    const compiled = fixture.debugElement.nativeElement;
    let icon = compiled.querySelector('[aria-label="delete icon"]');
    expect(icon).toBeTruthy();
    icon.click();
    fixture.detectChanges();
    expect(editSpy).toHaveBeenCalled();
  });

  it("should call setAllSelected for checkbox", () => {
    spyOn(component, "setAllSelected");
    const compiled = fixture.debugElement.nativeElement;
    const box = compiled.querySelector("#selectAll") as HTMLInputElement;

    box.dispatchEvent(new Event("change"));

    fixture.detectChanges();
    expect(component.setAllSelected).toHaveBeenCalled();
  });

  it("should call getuser service", () => {
    spyOn(service, "binarySearch");
    component.getUser(2);
    expect(service.binarySearch).toHaveBeenCalled();
  });

  it("should call updateselected for calling delete", () => {
    let called = spyOn(component, "updateSelected");
    let calledService = spyOn(service, "deleteUser");
    component.delete(1);
    expect(called).toHaveBeenCalled();
    expect(calledService).toHaveBeenCalledWith(0);
  });

  it("should call dataservice for valid edit", () => {
    let calledService = spyOn(service, "updateUser");
    component.userPlaceHolder = mockData[0];
    component.emailValidator = { invalid: false };
    component.nameValidator = { invalid: false };
    component.update();
    expect(calledService).toHaveBeenCalled();
  });

  it("should not call dataservice for invalid edit", () => {
    let calledService = spyOn(service, "updateUser");
    component.userPlaceHolder = mockData[0];
    component.emailValidator = { invalid: true };
    component.nameValidator = { invalid: false };
    expect(calledService).not.toHaveBeenCalled();
  });

  it("should return true for editing correct object", () => {
    component.userPlaceHolder = mockData[0];
    expect(component.edit(mockData[0])).toBeTruthy();
  });
  it("should return false for editing correct object", () => {
    component.userPlaceHolder = mockData[0];
    expect(component.edit(mockData[1])).toBeFalsy();
  });

  it("should return false when nothing is selected", () => {
    component.allSelected = false;
    expect(component.someSelected()).toBeFalsy();
  });

  it("should return false when all are selected", () => {
    component.allSelected = true;
    expect(component.someSelected()).toBeFalsy();
  });

  it("should return true when some are selected", () => {
    component.allSelected = false;
    component.dataSource[0].isSelected = true;
    expect(component.someSelected()).toBeTruthy();
    component.dataSource[0].isSelected = false;
  });

  it("should show save icon in edit mode", () => {
    let compiled = fixture.debugElement.nativeElement;
    const icon = compiled.querySelector('[aria-label="edit icon"]');
    icon.click();
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
    const save = compiled.querySelector('[aria-label="save icon"]');
    expect(save).toBeTruthy();
    fixture.debugElement.nativeElement
      .querySelector('[aria-label="cancel icon"]')
      .click();
    fixture.detectChanges();
  });

  it("should display name in textbox in edit mode", fakeAsync(() => {
    let compiled = fixture.debugElement.nativeElement;
    const icon = compiled.querySelector('[aria-label="edit icon"]');
    icon.click();
    fixture.detectChanges();
    tick();
    compiled = fixture.debugElement.nativeElement;
    const cancel = compiled.querySelector("table input");
    expect(cancel).toBeTruthy();
    fixture.debugElement.nativeElement
      .querySelector('[aria-label="cancel icon"]')
      .click();
    fixture.detectChanges();
  }));

  it("should unsubscribe alive subscription on destroy", () => {
    spyOn(component, "ngOnDestroy");
    fixture.destroy();
    expect(component.ngOnDestroy).toHaveBeenCalled();
    expect(component.dataServiceSubscription.closed).toBeTruthy();
  });
});
