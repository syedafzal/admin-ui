export interface user {
  id: number;
  name: string;
  email: string;
  role: string;
  isSelected?: boolean;
  isEditOn?: boolean;
}
