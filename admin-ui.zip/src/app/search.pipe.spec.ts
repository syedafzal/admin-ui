import { SearchPipe } from "./search.pipe";
import { user } from "./user.interface";

describe("SearchPipe", () => {
  const mockData: user[] = [
    {
      id: 1,
      name: "Aaron Miles",
      email: "aaron@mailinator.com",
      role: "member",
    },
    {
      id: 2,
      name: "Aishwarya Naik",
      email: "aishwarya@mailinator.com",
      role: "admin",
    },
    {
      id: 3,
      name: "Arvind Kumar",
      email: "arvind@mailinator.com",
      role: "admin",
    },
  ];
  let pipe: SearchPipe;
  beforeEach(() => {
    pipe = new SearchPipe();
  });

  it("should create an instance", () => {
    expect(pipe).toBeTruthy();
  });

  it("should filter on name", () => {
    expect(pipe.transform(mockData, "miles")).toEqual([mockData[0]]);
  });

  it("should filter on role", () => {
    expect(pipe.transform(mockData, "member")).toEqual([mockData[0]]);
  });

  it("should filter on email", () => {
    expect(pipe.transform(mockData, "@mailinator")).toEqual(mockData);
  });

  it("should filter on negative match", () => {
    expect(pipe.transform(mockData, "angular")).toEqual([]);
  });
});
